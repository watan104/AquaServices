#include <enet/enet.h>

class ENetWrapper {
public:

private:

};